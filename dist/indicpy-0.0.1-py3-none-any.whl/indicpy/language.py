# The language mapping for 2 and 3 character language code.
language_dict = {
	"kn": "kannada",
	"kan": "kannada",
	"hi": "hindi",
	"hin": "hindi",
}
